"use client";

import React from "react";
import Link from "next/link";
import { Box } from "@mui/material";
import { usePathname } from "next/navigation";
import YenInventoryPage from "../page";

const subItems = [
  {
    label: "Outlet Physical Stock",
    path: "/yen-inventory/OutletsInventoryManagement/OutletPhysicalStockModification",
  },
  {
    label: "Outlet Stock Variance",
    path: "/yen-inventory/OutletsInventoryManagement/OutletPhysicalStockVarianceModification",
  },
  {
    label: "Outlet Approved Stock",
    path: "/yen-inventory/OutletsInventoryManagement/ApprovedStock",
  },
  {
    label: "Outlet Stock Ledger",
    path: "/yen-inventory/OutletsInventoryManagement/ledger",
  },
];

const OutletsInventoryManagementPage = () => {
  const pathname = usePathname();

  return (
    <Box sx={{ width: "100%" }}>
      <YenInventoryPage />

      <nav
        className="inventory-section-nav"
        aria-label="Outlet inventory screens"
      >
        <div className="inventory-section-nav-list">
          {subItems.map((item) => {
            const isActive = pathname?.startsWith(item.path);

            return (
              <Link
                key={item.path}
                href={item.path}
                prefetch={false}
                className={`inventory-section-tab ${isActive ? "is-active" : ""}`}
                aria-current={isActive ? "page" : undefined}
                title={item.label}
              >
                {item.label}
              </Link>
            );
          })}
        </div>
      </nav>
    </Box>
  );
};

export default OutletsInventoryManagementPage;
