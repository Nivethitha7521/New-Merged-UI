"use client";

import React from "react";
import Link from "next/link";
import { Box } from "@mui/material";
import { usePathname } from "next/navigation";
import YenInventoryPage from "../page";

const subItems = [
  {
    label: "Warehouse Physical Stock",
    path: "/yen-inventory/WarehouseInventoryManagement/stockModification",
  },
  {
    label: "Warehouse Stock Variance",
    path: "/yen-inventory/WarehouseInventoryManagement/storeStockModification",
  },
  {
    label: "Warehouse Approved Stock",
    path: "/yen-inventory/WarehouseInventoryManagement/ApprovedStock",
  },
  {
    label: "Warehouse Stock Ledger",
    path: "/yen-inventory/WarehouseInventoryManagement/ledger",
  },
];

const WarehouseInventoryManagementPage = () => {
  const pathname = usePathname();

  return (
    <Box sx={{ width: "100%" }}>
      <YenInventoryPage />

      <nav
        className="inventory-section-nav"
        aria-label="Warehouse inventory screens"
      >
        <div className="inventory-section-nav-list">
          {subItems.map((item) => {
            const isActive = pathname?.startsWith(item.path);

            return (
              <Link
                key={item.path}
                href={item.path}
                prefetch={false}
                className={`inventory-section-tab ${isActive ? "is-active" : ""}`}
                aria-current={isActive ? "page" : undefined}
                title={item.label}
              >
                {item.label}
              </Link>
            );
          })}
        </div>
      </nav>
    </Box>
  );
};

export default WarehouseInventoryManagementPage;
