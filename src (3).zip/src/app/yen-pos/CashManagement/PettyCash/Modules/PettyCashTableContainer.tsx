'use client';
import React, { useState } from 'react';
import {
  Box,
  CircularProgress,IconButton,
  TextField,
  Typography,
} from '@mui/material';
import EditOutlinedIcon from '@mui/icons-material/EditOutlined';
import RestoreRoundedIcon from '@mui/icons-material/RestoreRounded';
import { PettyCash } from '../Models/pettycashModels';
import { usePermissions } from '@/hooks/usePermissions';
import PermissionIconButton from '@/components/Permissions/PermissionIconButton';
 

interface PettyCashTableProps {
  data: PettyCash[];
  isDeactivatedView: boolean;
  onEdit: (cash: PettyCash) => void;
  onDeactivate: (cash: PettyCash) => void;
  onActivate: (cash: PettyCash) => void;
 onApplyAll?: (value: string, allBranches: string[]) => Promise<void>;
  applyingAll?: boolean;
  allBranches: string[];
}

export const PettyCashTable: React.FC<PettyCashTableProps> = ({
  data,
  isDeactivatedView,
  onEdit,
  onDeactivate,
  onActivate,
  onApplyAll,
  applyingAll = false,
  allBranches,
}) => {


  const [applyAllValue, setApplyAllValue] = useState<string>('');
const { hasPermission } = usePermissions();
  const canEdit = hasPermission('pos', 'petty_cash', 'edit');
  const handleApplyAll = async () => {
    const trimmed = applyAllValue.trim();
    if (!trimmed || isNaN(Number(trimmed))) {
      alert('Please enter a valid number');
      return;
    }

    if (onApplyAll) {
      await onApplyAll(trimmed, allBranches);
     setApplyAllValue('');
    }
  };


  return (
    <>
    <Box className="item-master-toolbar-shell">
        <Box className="purchase-reference-toolbar item-master-toolbar">
          <Box sx={{ flex: 1, minWidth: 0 }}>
            <Typography className="yen-pos-toolbar-title">
              Petty Cash
            </Typography>
          </Box>

          <Box className="purchase-reference-actions item-master-actions">
            <TextField
             placeholder="Apply All (₹)"
              size="small"
             autoComplete="off"
              value={applyAllValue}
              //onChange={(e) => setApplyAllValue(e.target.value)}

              onChange={(e) => {
                const value = e.target.value;

                // Allow only digits (no decimals, max 4 digits optional)
                if (/^\d{0,4}$/.test(value)) {
                  setApplyAllValue(value);
                }
              }}

             onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  void handleApplyAll();
                }
              }}
              inputProps={{ min: 0, step: '0.01' }}
            
             disabled={applyingAll || !canEdit}
             className="custom-textfield yen-pos-apply-all-input"
            />
           <button
              type="button"
              className="item-master-price-button"
              onClick={() => void handleApplyAll()}
             disabled={!applyAllValue.trim() || applyingAll || !canEdit}
            >
              {applyingAll && <CircularProgress size={12} />}
              {applyingAll ? 'Applying...' : 'Apply'}
            </button>
          </Box>
        </Box>
      </Box>

     <div className="item-master-table-container">
        <table className="item-master-table item-master-lookup-table item-master-lookup-table--4 yen-pos-cash-table">
          <thead>
            <tr>
             <th>S.NO</th>
              <th>Branch Name</th>
              <th>Petty Cash</th>
              <th>Actions</th>
            </tr>
          </thead>

          <tbody>
            {data.map((cash, index) => (
 <tr
                key={cash.pettyCashId || cash.branches}
                className="item-master-data-row"
              >
                <td>{index + 1}</td>
                <td>{cash.branches}</td>
                <td>{cash.pettyCashId ? cash.pettyCash : '0'}</td>
             <td className="item-master-actions-cell">
  <div>
    {isDeactivatedView ? (
     <PermissionIconButton
        app="pos"
        module="petty_cash"
        action="edit"
        rollback
        tooltip="Activate"
        onClick={() => onActivate(cash)}
        icon={<RestoreRoundedIcon />}
        className="purchase-master-action-button is-activate"
        ariaLabel="Activate"
      />
    ) : (
      <PermissionIconButton
        app="pos"
        module="petty_cash"
        action="edit"
        tooltip="Edit"
        onClick={() => onEdit(cash)}
        icon={<EditOutlinedIcon />}
        className="purchase-master-action-button is-edit"
       ariaLabel="Edit"
      />
    )}
  </div>
</td>
              </tr>
            ))}

            {data.length === 0 && (
              <tr>
               <td colSpan={4} className="empty-state">
                  <h2>No data found</h2>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </>

    // </Box >
  );
};