


'use client';
import React, { useRef, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { RootState, AppDispatch } from '../../../../../redux/store';
import {
  IconButton,
  Switch,
  FormControlLabel,
  CircularProgress,
  Box,
  Typography,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  Button,
  Pagination,
} from '@mui/material';
import {
  Add as AddIcon, Edit as EditIcon,
  GetApp as GetAppIcon, Upload as UploadIcon,
  Description as DescriptionIcon,
  Undo as UndoIcon, Search as SearchIcon
} from '@mui/icons-material';
import { ExportCSV, ExportSfgheader, fetchSfg, ImportSfg, rollbackSfg, setSnackbarMessage, setSnackbarOpen } from '../Features/sfgSlice';
import DeleteIcon from '@mui/icons-material/Delete';
import RefreshIcon from '@mui/icons-material/Refresh';
import { SFG } from "../Models/sfgModels";
import ImportResultDialog, { ImportResultData } from '@/app/Components/ImportResultDialog';
import { usePermissions } from '@/hooks/usePermissions';
import PermissionButton from '@/components/Permissions/PermissionButton';
import PermissionIconButton from '@/components/Permissions/PermissionIconButton';

interface SfgTableContainerProps {
  handleEdit: (sfg: SFG) => void;
  handleDeactivate: (sfg: SFG) => void;
  handleActivate: (sfg: SFG) => void;
  handleOpen: () => void;
  showDeactivated: boolean;
  setShowDeactivated: (value: boolean) => void;
  searchValue: string;
  setSearchValue: (value: string) => void;
}

const SfgTableContainer: React.FC<SfgTableContainerProps> = ({
  handleEdit,
  handleDeactivate,
  handleActivate,
  handleOpen,
  showDeactivated,
  setShowDeactivated,
  searchValue,
  setSearchValue
}) => {
  const dispatch = useDispatch<AppDispatch>();
  const {
    items: sfg,
    deactivatedItems,
    loading,
    error,
    page,
    totalPages
  } = useSelector((state: RootState) => state.sfg);
  const { hasPermission } = usePermissions();
  const canEditSfg = hasPermission('masteradmin', 'sfg', 'edit');
  const canDeleteSfg = hasPermission('masteradmin', 'sfg', 'delete');

  const displayedSfg = showDeactivated ? deactivatedItems : sfg;
  const [isDownloadingSample, setIsDownloadingSample] = useState(false);


  // ── NEW: Import result dialog state ──────────────────────────────────────
  const [importResultDialogOpen, setImportResultDialogOpen] = useState(false);
  const [importResult, setImportResult] = useState<ImportResultData | null>(null);


  // Import/Export States
  const [isImporting, setIsImporting] = useState(false);
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [importMode, setImportMode] = useState<'import' | 'merge' | 'replace'>('import');
  const [errorDialogOpen, setErrorDialogOpen] = useState(false);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [confirmDialogOpen, setConfirmDialogOpen] = useState(false);
  const [confirmationMessage, setConfirmationMessage] = useState('');
  const [confirmationAction, setConfirmationAction] = useState<() => Promise<void>>(
    () => Promise.resolve()
  );

  const fileInputRef = useRef<HTMLInputElement>(null);


  const handleExportCSV = () => {
    dispatch(ExportCSV());
  };


  const isAnyActionLoading = isImporting || isDownloadingSample;




  // Open file picker when import icon is clicked
  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  // When file is selected, open the import dialog
  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const validExtensions = ['.csv', '.xlsx', '.xls'];
      const fileExtension = file.name.toLowerCase().substring(file.name.lastIndexOf('.'));

      if (!validExtensions.includes(fileExtension)) {
        dispatch(setSnackbarMessage('Please upload a valid CSV or Excel file'));
        dispatch(setSnackbarOpen(true));
        return;
      }

      setSelectedFile(file);
      setImportMode('import'); // Default mode
      setImportDialogOpen(true);
    }

    // Reset input
    if (event.target) {
      event.target.value = '';
    }
  };

  // // Handle import submission with selected mode
  // const handleImportSubmit = async () => {
  //   if (!selectedFile) return;

  //   setIsImporting(true);
  //   setImportDialogOpen(false);

  //   try {
  //     await dispatch(ImportSfg({ file: selectedFile, mode: importMode })).unwrap();
  //     dispatch(fetchSfg({ search: '', page: 1 }));
  //     setValidationErrors([]); // Clear any previous errors
  //   } catch (error: any) {
  //     console.error('Import error:', error);

  //     // Handle validation errors from backend
  //     if (error && typeof error === 'object') {
  //       if (error.errors && Array.isArray(error.errors) && error.errors.length > 0) {
  //         // Show validation errors in dialog
  //         setValidationErrors(error.errors);
  //         setErrorDialogOpen(true);
  //       } else if (error.message && typeof error.message === 'string') {
  //         // Show general error in snackbar (already handled in slice, but as fallback)
  //         dispatch(setSnackbarMessage(error.message));
  //         dispatch(setSnackbarOpen(true));
  //       }
  //     } else if (typeof error === 'string') {
  //       dispatch(setSnackbarMessage(error));
  //       dispatch(setSnackbarOpen(true));
  //     } else {
  //       dispatch(setSnackbarMessage('Failed to import Subcategory data'));
  //       dispatch(setSnackbarOpen(true));
  //     }
  //   } finally {
  //     setIsImporting(false);
  //     setSelectedFile(null);
  //   }
  // };



  const handleImportSubmit = async () => {
  if (!selectedFile) return;

  setIsImporting(true);
  setImportDialogOpen(false);

  try {
    // unwrap() returns the ImportResultData from the slice
    const result = await dispatch(
      ImportSfg({ file: selectedFile, mode: importMode })
    ).unwrap();

    // Refresh table
    dispatch(fetchSfg({ search: '', page: 1 }));
    setValidationErrors([]);

    // ── Open the result dialog with backend response ───────────────────
    setImportResult(result as unknown as ImportResultData);
    setImportResultDialogOpen(true);

  } catch (error: any) {
    console.error('Import error:', error);

    if (error && typeof error === 'object') {
      if (error.errors && Array.isArray(error.errors) && error.errors.length > 0) {
        // File-level validation errors → show in the error dialog
        setValidationErrors(error.errors);
        setErrorDialogOpen(true);
      } else if (error.message && typeof error.message === 'string') {
        dispatch(setSnackbarMessage(error.message));
        dispatch(setSnackbarOpen(true));
      }
    } else if (typeof error === 'string') {
      dispatch(setSnackbarMessage(error));
      dispatch(setSnackbarOpen(true));
    } else {
      dispatch(setSnackbarMessage('Failed to import SFG data'));
      dispatch(setSnackbarOpen(true));
    }
  } finally {
    setIsImporting(false);
    setSelectedFile(null);
  }
};


  // Handle rollback
  const handleRollback = async () => {
    setConfirmationMessage(
      'Are you sure you want to rollback to the previous data? This will undo the last replace operation.'
    );
    setConfirmationAction(() => async () => {
      try {
        await dispatch(rollbackSfg()).unwrap();
        dispatch(fetchSfg({ search: '', page: 1 }));
        setConfirmDialogOpen(false);
      } catch (error) {
        console.error('Rollback error:', error);
        setConfirmDialogOpen(false);
      }
    });
    setConfirmDialogOpen(true);
  };

  // Handle download sample CSV
  const handleDownloadSampleCSV = async () => {
    setIsImporting(true);
    try {
      await dispatch(ExportSfgheader()).unwrap();
      dispatch(setSnackbarMessage('Sample CSV downloaded successfully'));
      dispatch(setSnackbarOpen(true));
    } catch (error) {
      dispatch(setSnackbarMessage('Failed to download sample CSV'));
      dispatch(setSnackbarOpen(true));
    } finally {
      setIsImporting(false);
    }
  };

  const handleImportDialogClose = () => {
    setImportDialogOpen(false);
    setSelectedFile(null);
  };




  const label = showDeactivated ? 'Show Activated' : 'Show Deactivated';

  return (
    <>
      <Box
        display="flex"
        flexDirection={{ xs: "column", sm: "row" }}
        alignItems={{ xs: "flex-start", sm: "center" }}
        justifyContent="space-between"
        gap={0}
        my={1}
        ml={1}
        px={{ xs: 2, sm: 3 }}
        sx={{ width: "99%", boxSizing: "border-box", mt: -2 }}
      >
        <Typography className='icon-action-label'
          sx={{
            fontFamily: "'Poppins', sans-serif",
            fontWeight: 750,
            margin: 0,
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
            maxWidth: "100%",
          }}
        >
          {showDeactivated ? "Deactivated SFG" : "Active SFG"}
        </Typography>


        <Box sx={{ position: "relative", width: "280px" }}>
          <SearchIcon
            sx={{
              position: "absolute",
              top: "50%",
              left: "10px",
              transform: "translateY(-50%)",
              color: "text.secondary",
              fontSize: "1.2rem",
              pointerEvents: "none", // prevents blocking typing
            }}
          />

          <input
            type="text"
            placeholder="Search SFG's ..."
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            style={{
              padding: '6px 10px 6px 38px',
              fontSize: '0.8rem',
              borderRadius: '6px',
              border: '1px solid #ccc',
              fontFamily: 'Poppins, sans-serif',
              width: '280px',
            }}
          />
        </Box>



        <div className="flex items-center gap-2.5">
          {!showDeactivated && (
            <>
              <div className="icon-action-wrapper">
               <PermissionIconButton
                  app="masteradmin"
                  module="sfg"
                  action="add"
                  tooltip="Add"
                  onClick={handleOpen}
                  icon={<AddIcon className="icon-action-svg" />}
                  className="icon-action-button"
                  ariaLabel="Add"
                  disabled={isImporting}
               />
                <Typography className="icon-action-label">Add</Typography>
              </div>

              <div className="icon-action-wrapper">
                <PermissionIconButton
                  app="masteradmin"
                  module="sfg"
                  action="add"
                  tooltip="Import"
                  onClick={handleImportClick}
                 icon={isImporting ? (
                    <CircularProgress size={20} className="icon-action-svg" />
                  ) : (
                    <GetAppIcon className="icon-action-svg" />
                  )}
                className="icon-action-button"
                  ariaLabel="Import"
                  disabled={isImporting}
                />
                <Typography className="icon-action-label">
                  {isImporting ? 'Importing...' : 'Import'}
                </Typography>
              </div>

              <div className="icon-action-wrapper">
                <IconButton
                  color="primary"
                  onClick={handleExportCSV}
                  className="icon-action-button"
                  size="small"
                  disabled={isImporting}
                >
                  <UploadIcon className="icon-action-svg" />
                </IconButton>
                <Typography className="icon-action-label">Export</Typography>
              </div>

              <div className="icon-action-wrapper">
                <IconButton
                  color="primary"
                  onClick={handleDownloadSampleCSV}
                  disabled={isImporting}
                  className="icon-action-button"
                  size="small"
                >
                  <DescriptionIcon className="icon-action-svg" />
                </IconButton>
                <Typography className="icon-action-label">Sample</Typography>
              </div>

              <div className="icon-action-wrapper">
               <PermissionIconButton
                  app="masteradmin"
                  module="sfg"
                  action="edit"
                  tooltip="Rollback"
                  onClick={handleRollback}
                  icon={<UndoIcon className="icon-action-svg" />}
                  className="icon-action-button"
                  ariaLabel="Rollback"
                  disabled={isImporting}
              />
                <Typography className="icon-action-label">Rollback</Typography>
              </div>
            </>
          )}
          <FormControlLabel
            control={
              <Switch
                checked={showDeactivated}
                onChange={() => setShowDeactivated(!showDeactivated)}
                color="primary"
                size="small"
                disabled={isImporting}
              />
            }
            label={label}
            sx={{
              marginLeft: 1,
              marginRight: 1,
              "& .MuiFormControlLabel-label": {
                fontSize: "0.75rem",
                fontFamily: "'Poppins', sans-serif",
              },
            }}
          />
        </div>
      </Box>



      {/* Hidden file input */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileSelect}
        accept=".csv,.xlsx,.xls"
        style={{ display: 'none' }}
      />

      {/* Import Mode Selection Dialog */}
      <Dialog
        open={importDialogOpen}
        onClose={handleImportDialogClose}
        PaperProps={{
          className: 'dialog-paper-small',
        }}
      >
        <DialogTitle
          className="dialog-title"
          sx={{ fontFamily: "'Poppins', sans-serif", fontWeight: 400 }}
        >
          Select Import Mode
        </DialogTitle>

        <DialogContent className="dialog-content">
          <Box sx={{ pt: 1 }}>
            <Typography
              variant="body2"
              sx={{ mb: 1, fontFamily: "'Poppins', sans-serif", fontSize: '0.7rem' }}
            >
              Selected file: <strong>{selectedFile?.name}</strong>
            </Typography>

            <Divider sx={{ my: 2 }} />

            <Typography
              sx={{
                fontFamily: "'Poppins', sans-serif",
                fontWeight: 500,
                mb: 2,
                fontSize: '0.8rem',
              }}
            >
              Choose import mode:
            </Typography>

            <Box
              sx={{
                display: 'flex',
                flexDirection: 'column',
                gap: 1.5,
                alignItems: 'center',
              }}
            >
              {/* IMPORT */}
              <Button
                variant={importMode === 'import' ? 'contained' : 'outlined'}
                color="primary"
                onClick={() => setImportMode('import')}
                sx={{ width: 180 }}
              >
                <Box>
                  <Typography fontWeight={500}>Import</Typography>
                </Box>
              </Button>

              {/* MERGE */}
              <Button
                variant={importMode === 'merge' ? 'contained' : 'outlined'}
                color="secondary"
                onClick={() => setImportMode('merge')}
                sx={{ width: 180 }}
              >
                <Box>
                  <Typography fontWeight={500}>Merge</Typography>
                </Box>
              </Button>

              {/* REPLACE */}
              <Button
                variant={importMode === 'replace' ? 'contained' : 'outlined'}
                color="error"
                onClick={() => setImportMode('replace')}
                sx={{ width: 180 }}
              >
                <Box>
                  <Typography fontWeight={500}>Replace</Typography>
                </Box>
              </Button>
            </Box>
          </Box>
        </DialogContent>

        <DialogActions className="dialog-actions" sx={{ px: 3, pb: 2 }}>
          <button className="btn-secondary" onClick={handleImportDialogClose}>
            Cancel
          </button>
          <button className="btn-primary" onClick={handleImportSubmit}>
            Confirm
          </button>
        </DialogActions>
      </Dialog>

      {/* Validation Error Dialog */}
      <Dialog
        open={errorDialogOpen}
        onClose={() => setErrorDialogOpen(false)}
        PaperProps={{
          className: 'dialog-paper-medium',
        }}
      >
        <DialogTitle
          className="dialog-title"
          sx={{
            fontFamily: "'Poppins', sans-serif",
            fontWeight: 600,
            color: 'error.main',
            display: 'flex',
            alignItems: 'center',
            gap: 1,
          }}
        >
          <Box
            component="span"
            sx={{
              backgroundColor: 'error.light',
              borderRadius: '50%',
              width: 32,
              height: 32,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'white',
            }}
          >
            !
          </Box>
          Validation Failed
        </DialogTitle>
        <DialogContent className="dialog-content">
          <Box sx={{ pt: 0 }}>
            <Typography
              variant="body1"
              sx={{
                mb: 2,
                fontFamily: "'Poppins', sans-serif",
                fontWeight: 500,
                fontSize: '0.7rem',
              }}
            >
              Import failed with {validationErrors.length} error(s):
            </Typography>

            <Box
              sx={{
                maxHeight: '400px',
                overflowY: 'auto',
                backgroundColor: '#f5f5f5',
                borderRadius: 1,
                p: 2,
              }}
            >
              {validationErrors.map((error, index) => (
                <Box
                  key={index}
                  sx={{
                    mb: 1.5,
                    p: 1.5,
                    backgroundColor: 'white',
                    borderLeft: '3px solid',
                    borderColor: 'error.main',
                    borderRadius: 1,
                    fontFamily: "'Poppins', sans-serif",
                  }}
                >
                  <Typography
                    variant="body2"
                    sx={{
                      fontFamily: "'Courier New', monospace",
                      fontSize: '0.85rem',
                      fontWeight: 600,
                      color: 'text.primary',
                    }}
                  >
                    {error}
                  </Typography>
                </Box>
              ))}
            </Box>

            <Typography
              variant="caption"
              sx={{
                mt: 2,
                display: 'block',
                fontFamily: "'Poppins', sans-serif",
                color: 'text.secondary',
              }}
            >
              Please fix the errors in your file and try importing again.
            </Typography>
          </Box>
        </DialogContent>
        <DialogActions className="dialog-actions" sx={{ px: 3, pb: 2 }}>
          <button
            className="btn-primary"
            onClick={() => setErrorDialogOpen(false)}
            color="primary"
          >
            Close
          </button>
        </DialogActions>
      </Dialog>

      {/* Confirmation Dialog */}
      <Dialog
        open={confirmDialogOpen}
        onClose={() => setConfirmDialogOpen(false)}
        PaperProps={{
          className: 'dialog-paper-small',
        }}
      >
        <DialogTitle
          className="dialog-title"
          sx={{ fontFamily: "'Poppins', sans-serif", fontWeight: 500 }}
        >
          Confirm Action
        </DialogTitle>
        <DialogContent className="dialog-content">
          <Typography sx={{ fontFamily: "'Poppins', sans-serif", fontSize: '0.9rem' }}>
            {confirmationMessage}
          </Typography>
        </DialogContent>
        <DialogActions className="dialog-actions" sx={{ px: 3, pb: 2 }}>
          <button className="btn-secondary" onClick={() => setConfirmDialogOpen(false)}>
            Cancel
          </button>
          <button
            className="btn-primary"
            onClick={() => {
              confirmationAction();
            }}
          >
            Confirm
          </button>
        </DialogActions>
      </Dialog>


      <div className="table-container my-1" style={{ maxHeight: 'calc(85.5vh - 170px)' }}>
        <table className="custom-table">
          <thead>
            <tr>
              <th>S.NO</th>
              <th>SFG Code</th>
              <th>SFG Name</th>
              <th>Price</th>
              <th>Uom</th>
              <th>ShelfLife</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={6} style={{ textAlign: 'center' }}>
                  <h3 style={{ fontWeight: 'bold' }}>Loading...</h3>
                </td>
              </tr>
            ) : (
              <>
                {displayedSfg.map((sfg, index) => (
                  <tr key={sfg.id || index}>
                    <td style={{ textAlign: 'center' }}>{index + 1}</td>
                    <td style={{ textAlign: 'center' }}>{sfg.sfgCode}</td>
                    <td style={{ textAlign: 'center' }}>{sfg.sfgName}</td>
                    <td style={{ textAlign: 'center' }}>{sfg.price}</td>
                    <td style={{ textAlign: 'center' }}>{sfg.uom}</td>
                    <td style={{ textAlign: 'center' }}>{sfg.shelfLife}</td>
                    <td style={{ textAlign: 'center' }}>
                      <div className="flex justify-center gap-1">
                        {showDeactivated ? (
                         canEditSfg && (
                            <button
                            onClick={() => handleActivate(sfg)}
                              className="activate-btn"
                              title="Activate"
                            >
                            <RefreshIcon fontSize="small" />
                            </button>
                                                      )
                        ) : (
                          <>
                            {canEditSfg && (
                              <button
                                onClick={() => handleEdit(sfg)}
                                className="edit-btn"
                                title="Edit"
                                style={{ fontSize: "16px" }}
                              >
                                <EditIcon fontSize="small" />
                              </button>
                            )}
                            {canDeleteSfg && (
                              <button
                                onClick={() => handleDeactivate(sfg)}
                                className="deactivate-btn"
                                title="Deactivate"
                              >
                                <DeleteIcon fontSize="small" />
                              </button>
                            )}
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
                {displayedSfg.length === 0 && (
                  <tr>
                    <td colSpan={6} className="empty-state">
                      <h2>
                        {showDeactivated ? 'No deactivated SFG found' : 'No active SFG found'}
                      </h2>
                    </td>
                  </tr>
                )}
              </>
            )}
          </tbody>
        </table>
      </div>

      {totalPages > 1 && (
        <Box display="flex" justifyContent="center" mt={0.5}>
          <Pagination
            count={totalPages}
            page={page}
            color="primary"
            onChange={(event, value) => {
              dispatch(fetchSfg({ search: searchValue, page: value }));
            }}
          />
        </Box>
      )}

      <ImportResultDialog
        open={importResultDialogOpen}
        onClose={() => {
          setImportResultDialogOpen(false);
          setImportResult(null);
        }}
        result={importResult}
        moduleName="Location"
      />
    </>
  );
};

export default SfgTableContainer;